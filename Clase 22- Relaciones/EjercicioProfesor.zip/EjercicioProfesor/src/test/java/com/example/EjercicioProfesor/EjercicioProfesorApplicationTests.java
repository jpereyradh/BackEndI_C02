package com.example.EjercicioProfesor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjercicioProfesorApplicationTests {

	@Test
	void contextLoads() {
	}

}
