package com.example.TablaMovimiento;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TablaMovimientoApplication {

	public static void main(String[] args) {
		SpringApplication.run(TablaMovimientoApplication.class, args);
	}

}
