package BackEndC3.Entrenador;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EntrenadorApplication {

	public static void main(String[] args) {
		SpringApplication.run(EntrenadorApplication.class, args);
	}

}
