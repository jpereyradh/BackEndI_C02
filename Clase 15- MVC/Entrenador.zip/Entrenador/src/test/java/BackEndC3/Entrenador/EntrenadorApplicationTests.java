package BackEndC3.Entrenador;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EntrenadorApplicationTests {

	@Test
	void contextLoads() {
	}

}
