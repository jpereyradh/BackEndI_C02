package com.example.DirectorTecnico;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DirectorTecnicoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DirectorTecnicoApplication.class, args);
	}

}
